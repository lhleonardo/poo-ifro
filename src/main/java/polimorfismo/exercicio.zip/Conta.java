package polimorfismo;

/**
 * @author Leonardo Braz
 *
 */
public class Conta {

	private Integer numero;
	private String nome;
	private double saldo;

	public Conta() {
	}

	public Conta(Integer numero, String nome) {
		this.numero = numero;
		this.nome = nome;
	}

	public Integer getNumero() {
		return this.numero;
	}

	public void setNumero(Integer numero) {
		this.numero = numero;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public String toString() {
		return "Conta (numero=" + this.numero + ", nome=" + this.nome + ", saldo=" + this.saldo + ")";
	}

	public double getSaldo() {
		return this.saldo;

	}

	public boolean sacar(double valor) {
		if (valor > 0 && valor <= this.saldo) {
			this.saldo -= valor;
			return true;
		} else {
			System.out.println("Valor negativo ou n�o possui saldo dispon�vel.");
			return false;
		}
	}

	public boolean deposita(double valor) {
		if (valor > 0) {
			this.saldo += valor;
			return true;
		} else {
			System.out.println("N�o � poss�vel depositar um valor negativo. Isso n�o � um saque!");
			return false;
		}
	}

}
